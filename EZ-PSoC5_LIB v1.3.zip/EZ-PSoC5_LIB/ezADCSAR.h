/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef EZADCSAR_H
#define EZADCSAR_H

#include "ezCOMM.h"
#include "TypeDefine.h"

#define CONNECT_ADCSAR8(X,Y)    X->ADCSAR_Start             = Y##_Start; \
                                X->ADCSAR_Stop              = Y##_Stop; \
                                X->ADCSAR_IsEndConversion   = Y##_IsEndConversion; \
                                X->ADCSAR_GetResult8        = Y##_GetResult8;

#define CONNECT_ADCSAR16(X,Y)   X->ADCSAR_Start             = Y##_Start; \
                                X->ADCSAR_Stop              = Y##_Stop; \
                                X->ADCSAR_IsEndConversion   = Y##_IsEndConversion; \
                                X->ADCSAR_GetResult16       = Y##_GetResult16;

    
    
    
typedef struct EZOBJ_ADCSAR{
    void*   PrivateData;
    
    void    (* ADCSAR_Start)(void);
    void    (* ADCSAR_Stop)(void);
    uint8   (* ADCSAR_IsEndConversion)(uint8);
    int8    (* ADCSAR_GetResult8)(void);
    int16   (* ADCSAR_GetResult16)(void);
} EZOBJ_ADCSAR;

typedef EZOBJ_ADCSAR * PEZOBJ_ADCSAR;

PEZOBJ_ADCSAR       ezADCSAR_Create();
void                ezADCSAR_Release(PEZOBJ_ADCSAR adc);
void                ezADCSAR_ConnectISR(PEZOBJ_ADCSAR adc, PEZOBJ_ISR isr);


bool                ezADCSAR_Init(PEZOBJ_ADCSAR adc);
void                ezADCSAR_Start(PEZOBJ_ADCSAR adc);

int16               ezADCSAR_GetResult(PEZOBJ_ADCSAR adc);

bool                ezADCSAR_IsUsedInterrupt(PEZOBJ_ADCSAR adc);

void                ezADCSAR_Register(PEZOBJ_ADCSAR adc, PSinglelLink PNewRegLink);



#endif

/* [] END OF FILE */
