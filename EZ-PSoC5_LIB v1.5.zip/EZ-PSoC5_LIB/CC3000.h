/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef CC3000_H
#define CC3000_H

#include "ezCOMM.h"
#include "ezSPI.h"
#include <cytypes.h>
#include "ezPSoC5.h"
#include "ezNETWORK.h"

// TI CC3000 WiFi
// SPI Protocol - CPHA = 1, CPOL = 0
//
    
//------------------------------------------------------------
// Defines ///////////////////////////////////////////////////
//------------------------------------------------------------

typedef enum{
    WLAN_SEC_NONE,
    WLAN_SEC_WPA2    
}
WLAN_SECURITY;

//------------------------------------------------------------
// Public Data Structure /////////////////////////////////////
//------------------------------------------------------------
typedef struct CC3000_CONFIG{
    bool            UseDHCP;
    char            NicName[6];
    
    uint8_t         *SSID;
    uint8_t         *Password;
    uint8_t         SPIAddress;     // SPI Address
    
    
} CC3000_CONFIG;
    
    
typedef struct EZOBJ_CC3000 {
    void*           PrivateData;
    
    CC3000_CONFIG   Config;

} EZOBJ_CC3000;

typedef EZOBJ_CC3000 * PEZOBJ_CC3000;


//------------------------------------------------------------
// Public Functions //////////////////////////////////////////
//------------------------------------------------------------
PEZOBJ_CC3000       CC3000_Create();
void                CC3000_Release(PEZOBJ_CC3000 cc);

void                CC3000_ConnectSPI(PEZOBJ_CC3000 cc, PEZOBJ_SPI spi);
void                CC3000_ConnectISR(PEZOBJ_CC3000 cc, PEZOBJ_ISR isr);
void                CC3000_ConnectVBEN(PEZOBJ_CC3000 cc, PEZOBJ_IO vben);

bool                CC3000_ConnectToAP(PEZOBJ_CC3000 cc, char* ssid, char* password, WLAN_SECURITY security);

void                CC3000_SetIP(PEZOBJ_CC3000 cc, uint32_t ip, uint32_t subnet[], uint32_t getway[]);
void                CC3000_SetDNS(PEZOBJ_CC3000 cc, uint32_t dns[]);

bool                CC3000_Init (PEZOBJ_CC3000 cc);
void                CC3000_Start(PEZOBJ_CC3000 cc);

void                CC3000_GetIP(PEZOBJ_CC3000 cc, uint8_t *ip, uint8_t *subnet, uint8_t *gateway);

    
    
    
#endif
/* [] END OF FILE */

