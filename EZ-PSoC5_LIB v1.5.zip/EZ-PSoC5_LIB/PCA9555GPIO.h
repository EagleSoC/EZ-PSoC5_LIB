/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/*
 * Chip Number : PCA9555
 * Description : 16-bit GPIO expansion with Interrupt
 * Manufacture : NXP
 * Web Site    : 
 * Interfaces  : I2C 400KHz
*/

#ifndef __PCA9555GPIO_H
#define __PCA9555GPIO_H
#include "ezCOMM.h"
    
typedef struct PCA9555GPIO_CONFIG{
    uint8_t         AddrA2A1A0;
    
    
} PCA9555GPIO_CONFIG;
typedef PCA9555GPIO_CONFIG * PPCA9555GPIO_CONFIG;

typedef struct EZOBJ_PCA9555GPIO
{
    void*               PrivateData;
    PCA9555GPIO_CONFIG  Config;
    
} EZOBJ_PCA9555GPIO;

typedef EZOBJ_PCA9555GPIO * PEZOBJ_PCA9555GPIO;


PEZOBJ_PCA9555GPIO  PCA9555GPIO_Create();
void                PCA9555GPIO_Release(PEZOBJ_PCA9555GPIO gpio);

void                PCA9555GPIO_ConnectI2C(PEZOBJ_PCA9555GPIO gpio, PEZOBJ_I2C i2c);

bool                PCA9555GPIO_Init (PEZOBJ_PCA9555GPIO gpio);
void                PCA9555GPIO_Start(PEZOBJ_PCA9555GPIO gpio);

// Setup Output Pins for GPIO0/GPIO1
// bit->0: Input
// bit->1: Output
void                PCA9555GPIO_SetPortDirection(PEZOBJ_PCA9555GPIO gpio, uint8_t port, uint8_t dir);
uint8_t             PCA9555GPIO_ReadPort(PEZOBJ_PCA9555GPIO gpio, uint8_t port);
void                PCA9555GPIO_WritePort(PEZOBJ_PCA9555GPIO gpio,uint8_t port, uint8_t  data);

uint8_t             PCA9555GPIO_ReadMaskPort(PEZOBJ_PCA9555GPIO gpio, uint8_t port, uint8_t mask);
void                PCA9555GPIO_WriteMaskPort(PEZOBJ_PCA9555GPIO gpio,uint8_t port, uint8_t mask, uint8_t  data);
    
    
    
    
#endif

/* [] END OF FILE */
