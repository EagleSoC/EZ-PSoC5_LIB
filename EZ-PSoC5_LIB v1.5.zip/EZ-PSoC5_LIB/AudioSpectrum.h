/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
//#include "CyLib.h"
//#include "Project.h"

#ifndef EZAUDIOSPECTRUM_H
#define EZAUDIOSPECTRUM_H
 
#include "ezCOMM.h"
#include "ezPSoC5.h"    
#include "ezADCSAR.h"
    
    
typedef struct EZOBJ_AUDIOSPECTRUM{
    void*   PrivateData;

    uint32  ezFilter[7];
    uint32* Filter_63Hz;
    uint32* Filter_160Hz;
    uint32* Filter_400Hz;
    uint32* Filter_1000Hz;
    uint32* Filter_2500Hz;
    uint32* Filter_6250Hz;
    uint32* Filter_16000Hz;
    
} EZOBJ_AUDIOSPECTRUM;
typedef EZOBJ_AUDIOSPECTRUM * PEZOBJ_AUDIOSPECTRUM;


PEZOBJ_AUDIOSPECTRUM    AUDIOSPECTRUM_Create();
void                    AUDIOSPECTRUM_Release(PEZOBJ_AUDIOSPECTRUM audio);

void                    AUDIOSPECTRUM_ConnectADCSAR(PEZOBJ_AUDIOSPECTRUM audio, PEZOBJ_ADCSAR adc);

bool                    AUDIOSPECTRUM_Init(PEZOBJ_AUDIOSPECTRUM audio);
void                    AUDIOSPECTRUM_Start(PEZOBJ_AUDIOSPECTRUM audio);

bool                    AUDIOSPECTRUM_IsDataReady(PEZOBJ_AUDIOSPECTRUM audio);

    
    
#endif

/* [] END OF FILE */

