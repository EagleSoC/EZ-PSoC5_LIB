/* ========================================
 *
 * Copyright AirSupplyLab.com, 2013
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF AirSupplyLab.com.
 *
 * Airs Lin
 * ========================================
*/

//------------------------------------------------------------
// *.h ///////////////////////////////////////////////////////
//------------------------------------------------------------

#ifndef ENC28J60_H
#define ENC28J60_H

#include "ezCOMM.h"
#include <cytypes.h>
#include "TypeDefine.h"
#include "ezNETWORKSTACK.h"

//------------------------------------------------------------
// Defines ///////////////////////////////////////////////////
//------------------------------------------------------------

typedef struct ENC28J60_CONFIG{

    EZ_IP_ADDR      IPAddr;
    EZ_MAC_ADDR     MACAddr;


} ENC28J60_CONFIG;
//------------------------------------------------------------
// Public Data Structure /////////////////////////////////////
//------------------------------------------------------------

typedef struct EZOBJ_ENC28J60 {
    void*               PrivateData;

    ENC28J60_CONFIG     Config;


} EZOBJ_ENC28J60;

typedef EZOBJ_ENC28J60 * PEZOBJ_ENC28J60;


//------------------------------------------------------------
// Public Functions //////////////////////////////////////////
//------------------------------------------------------------
PEZOBJ_ENC28J60    ENC28J60_Create();
void                ENC28J60_Release(PEZOBJ_ENC28J60 enc);

void                ENC28J60_ConnectI2C(PEZOBJ_ENC28J60 enc, PEZOBJ_I2C i2c);
void                ENC28J60_ConnectSPI(PEZOBJ_ENC28J60 enc, PEZOBJ_SPI isp);

bool                ENC28J60_Init (PEZOBJ_ENC28J60 enc);
void                ENC28J60_Start(PEZOBJ_ENC28J60 enc);






#endif