/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef IMU_4D_ALGORITHM_H
#define IMU_4D_ALGORITHM_H


#include <cytypes.h>
#include "TypeDefine.h"

//------------------------------------------------------------
// Defines ///////////////////////////////////////////////////
//------------------------------------------------------------


//------------------------------------------------------------
// Public Data Structure /////////////////////////////////////
//------------------------------------------------------------

typedef struct EZOBJ_IMU4D {
    void*       PrivateData;

    float       roll;
    float       pitch;
    float       yaw;
} EZOBJ_IMU4D;

typedef EZOBJ_IMU4D * PEZOBJ_IMU4D;


//------------------------------------------------------------
// Public Functions //////////////////////////////////////////
//------------------------------------------------------------
PEZOBJ_IMU4D       IMU4D_Create();
void                IMU4D_Release(PEZOBJ_IMU4D imu4d);

void                IMU4D_PlugGyroIF(PEZOBJ_IMU4D imu4d, PEZOBJ_INTERFACE gyro);
void                IMU4D_PlugAccIF (PEZOBJ_IMU4D imu4d, PEZOBJ_INTERFACE acc);
void                IMU4D_PlugMagIF (PEZOBJ_IMU4D imu4d, PEZOBJ_INTERFACE msg);

bool                IMU4D_Init (PEZOBJ_IMU4D imu4d);
void                IMU4D_Start(PEZOBJ_IMU4D imu4d);

bool                IMU4D_MeasureCurrentPositions(PEZOBJ_IMU4D imu4d);








#endif
//[] END OF FILE