/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef __EZPSOC5_H
#define __EZPSOC5_H

//#include "cytypes.h"
//#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "ezCOMM.h"
    
#ifndef HIGH
#define HIGH 1
#endif

#ifndef LOW
#define LOW 0
#endif

#ifndef ToDeg
#define ToDeg(x) ((x)*57.2957795131)  // *180/pi
#endif

#ifndef ToRad
#define ToRad(x) ((x)*0.01745329252)  // *pi/180
#endif

#ifndef VECTOR_3D
#define VECTOR_3D
typedef struct VECTOR3Df
{
    float   x, y, z;
} VECTOR3Df;
typedef VECTOR3Df * PVECTOR3Df;

typedef struct VECTOR3D
{
    int32_t     x, y, z;
} VECTOR3D;
typedef VECTOR3D * PVECTOR3D;
#endif

#define _PORT0  (1 << 0)
#define _PORT1  (1 << 1)
#define _PORT2  (1 << 2)
#define _PORT3  (1 << 3)
#define _PORT4  (1 << 4)
#define _PORT5  (1 << 5)
#define _PORT6  (1 << 6)
#define _PORT7  (1 << 7)

#define _PORTA  (1 << 0)
#define _PORTB  (1 << 1)
#define _PORTC  (1 << 2)
#define _PORTD  (1 << 3)
#define _PORTE  (1 << 4)
#define _PORTF  (1 << 5)
#define _PORTG  (1 << 6)
#define _PORTH  (1 << 7)

#define _PIN0   (1 << 0)
#define _PIN1   (1 << 1)
#define _PIN2   (1 << 2)
#define _PIN3   (1 << 3)
#define _PIN4   (1 << 4)
#define _PIN5   (1 << 5)
#define _PIN6   (1 << 6)
#define _PIN7   (1 << 7)

#define _BIT0   (1 << 0)
#define _BIT1   (1 << 1)
#define _BIT2   (1 << 2)
#define _BIT3   (1 << 3)
#define _BIT4   (1 << 4)
#define _BIT5   (1 << 5)
#define _BIT6   (1 << 6)
#define _BIT7   (1 << 7)

#define _BIT8   (1 << 8)
#define _BIT9   (1 << 9)
#define _BIT10  (1 << 10)
#define _BIT11  (1 << 11)
#define _BIT12  (1 << 12)
#define _BIT13  (1 << 13)
#define _BIT14  (1 << 14)
#define _BIT15  (1 << 15)

#define _BIT16  (1 << 16)
#define _BIT17  (1 << 17)
#define _BIT18  (1 << 18)
#define _BIT19  (1 << 19)
#define _BIT20  (1 << 20)
#define _BIT21  (1 << 21)
#define _BIT22  (1 << 22)
#define _BIT23  (1 << 23)
                      
#define _BIT24  (1 << 24)
#define _BIT25  (1 << 25)
#define _BIT26  (1 << 26)
#define _BIT27  (1 << 27)
#define _BIT28  (1 << 28)
#define _BIT29  (1 << 29)
#define _BIT30  (1 << 30)
#define _BIT31  (1 << 31)








#endif  // TYPEDEF_H
//[] END OF FILE
