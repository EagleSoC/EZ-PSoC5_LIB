/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef _TM1637LED_H
#define _TM1637LED_H

#include "TM1637LED.h"
#include "ezPSoC5.h"
    

//------------------------------------------------------------
// Defines ///////////////////////////////////////////////////
//------------------------------------------------------------

typedef struct EZOBJ_TM1637LED
{
    void*           PrivateData;

} EZOBJ_TM1637LED;

typedef EZOBJ_TM1637LED * PEZOBJ_TM1637LED;



PEZOBJ_TM1637LED    TM1637LED_Create();
void                TM1637LED_Release(PEZOBJ_TM1637LED led);

void                TM1637LED_ConnectCLK(PEZOBJ_TM1637LED led, PEZOBJ_IO clk);
void                TM1637LED_ConnectDIO(PEZOBJ_TM1637LED led, PEZOBJ_IO dio);

bool                TM1637LED_Start(PEZOBJ_TM1637LED led);

void                TM1637LED_SetBrightness(PEZOBJ_TM1637LED led, uint8_t brightness, bool on);
void                TM1637LED_SetSegments(PEZOBJ_TM1637LED led, uint8_t segments[], uint8_t length, uint8_t position);

void                TM1637LED_ClearDisplay(PEZOBJ_TM1637LED led);
void                TM1637LED_ShowNumberDec(PEZOBJ_TM1637LED led, int num, bool leading_zero, uint8_t length, uint8_t pos);
void                TM1637LED_ShowNumberDecEx(PEZOBJ_TM1637LED led, int num, uint8_t dots, bool leading_zero, uint8_t length, uint8_t pos);
void                TM1637LED_ShowNumberHexEx(PEZOBJ_TM1637LED led, uint16_t num, uint8_t dots, bool leading_zero,uint8_t length, uint8_t pos);
void                TM1637LED_ShowNumberBaseEx(PEZOBJ_TM1637LED led, int8_t base, uint16_t num, uint8_t dots, bool leading_zero, uint8_t length, uint8_t pos);
 

#endif
/* [] END OF FILE */
