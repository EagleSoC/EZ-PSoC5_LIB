/* ========================================
 *
 * Copyright AirSupplyLab.com, 2013
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF AirSupplyLab.com.
 *
 * Airs Lin
 * ========================================
*/

//------------------------------------------------------------
// *.h ///////////////////////////////////////////////////////
//------------------------------------------------------------

#ifndef WIZ5500_H
#define WIZ5500_H

#include "ezCOMM.h"
#include <cytypes.h>
#include "ezPSoC5.h"
#include "ezNETWORK.h"

//------------------------------------------------------------
// Defines ///////////////////////////////////////////////////
//------------------------------------------------------------


//typedef enum{
//    WIZ5500_W5100,
//    WIZ5500_W5200,
//    WIZ5500_W5500
//} WIZ5500_TYPE;

typedef enum{
    WIZ5500_


} WIZ5500_CONF_PHYMODE;

//typedef enum{


//} WIZ5500_DUPLEX_STATUS;

//------------------------------------------------------------
// Public Data Structure /////////////////////////////////////
//------------------------------------------------------------


typedef struct WIZ5500_CONFIG{
    uint8_t         SPIAddress;
    bool            UseDHCP;
//  WIZ5500_TYPE    Type;
    uint8_t         EnablePingEcho:1,EnableWakeOnLAN:1, EnableForceARP:1;
    char            NicName[6];



} WIZ5500_CONFIG;



typedef struct EZOBJ_WIZNET5 {
    void*       PrivateData;

    WIZ5500_CONFIG   Config;

} EZOBJ_WIZNET5;

typedef EZOBJ_WIZNET5 * PEZOBJ_WIZNET5;


//------------------------------------------------------------
// Public Functions //////////////////////////////////////////
//------------------------------------------------------------
PEZOBJ_WIZNET5      WIZ5500_Create();
void                WIZ5500_Release(PEZOBJ_WIZNET5 w5);

void                WIZ5500_ConnectSPI(PEZOBJ_WIZNET5 w5, PEZOBJ_SPI isp);
void                WIZ5500_ConnectResetPin(PEZOBJ_WIZNET5 w5, PEZOBJ_IO reset);
void                WIZ5500_ConnectReadyPin(PEZOBJ_WIZNET5 w5, PEZOBJ_IO rdy);
void                WIZ5500_ConnectISR(PEZOBJ_WIZNET5 w5, PEZOBJ_ISR isr);

void                WIZ5500_SetStaticIPAddr(PEZOBJ_WIZNET5 w5, uint8_t ip[], uint8_t subnet[], uint8_t gateway[]);
void                WIZ5500_SetMACAddr(PEZOBJ_WIZNET5 w5, uint8_t mac[]);

bool                WIZ5500_Init (PEZOBJ_WIZNET5 w5);
void                WIZ5500_Start(PEZOBJ_WIZNET5 w5);

bool                WIZ5500_GetMACAddr(PEZOBJ_WIZNET5 w5, uint8_t *macAddr);
void                WIZ5500_GetIP(PEZOBJ_WIZNET5 w5, uint8_t *ip, uint8_t *subnet, uint8_t *gateway);








#endif
/* [] END OF FILE */
