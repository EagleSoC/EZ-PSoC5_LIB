/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/*
 * Chip Number : DS1307RTC
 * Description : 64 x 8 Serial Real-Time Clock
 * Manufacture : Dallas Semiconductor
 * Web Site    : http://www.maxim-ic.com
 * Interfaces  : I2C
*/


#ifndef _DS1307RTC_H
#define _DS1307RTC_H

#include "ezPSoC5.h"
#include <cytypes.h>

//------------------------------------------------------------
// Defines ///////////////////////////////////////////////////
//------------------------------------------------------------


#define DS1307RTC_SQW_RATE_1HZ      0x00
#define DS1307RTC_SQW_RATE_4096HZ   0x01
#define DS1307RTC_SQW_RATE_8192HZ   0x02
#define DS1307RTC_SQW_RATE_32768HZ  0x03

#if !defined(EZDATETIME_STRUCT)
    #define EZDATETIME_STRUCT
    
    #pragma pack(push)  // push current alignment to stack
    #pragma pack (1)    // Set alignment to 1 byte boundary
    typedef struct EZDATETIME {
        uint8   second;
        uint8   minute;
        uint8   hour24;
        uint8   dayOfWeek;
        uint8   day;
        uint8   month;
        uint16  year;
    } EZDATETIME;
    #pragma pack(pop)   // Restore original alignment from stack
    typedef EZDATETIME * PEZDATETIME;
    
    typedef enum EZDAYOFWEEK{
        SUNDAT = 0,
        MONDAY,
        TUESDAY,
        WEDNESDAY,
        THURSDAY,
        FRIDAY,
        SATURDAY
    } EZDAYOFWEEK;
    
#endif                  // !defined(EZDATETIME_STRUCT)

typedef struct EZOBJ_DS1307RTC
{
    void*           PrivateData;

} EZOBJ_DS1307RTC;

typedef EZOBJ_DS1307RTC * PEZOBJ_DS1307RTC;


PEZOBJ_DS1307RTC    DS1307RTC_Create();
void                DS1307RTC_Release(PEZOBJ_DS1307RTC ds);

void                DS1307RTC_ConnectI2C(PEZOBJ_DS1307RTC ds, PEZOBJ_I2C i2c);

bool                DS1307RTC_Init (PEZOBJ_DS1307RTC ds);
void                DS1307RTC_Start(PEZOBJ_DS1307RTC ds);

bool                DS1307RTC_Now(PEZOBJ_DS1307RTC ds, PEZDATETIME datetime);

bool                DS1307RTC_SetDateTime(PEZOBJ_DS1307RTC ds, PEZDATETIME datetime);
bool                DS1307RTC_SetDate(PEZOBJ_DS1307RTC ds, uint16 year, uint8 month, uint8 day, uint8 dayOfWeek);
bool                DS1307RTC_SetTime(PEZOBJ_DS1307RTC ds, uint8 hour24, uint8 minute, uint8 second);

bool                DS1307RTC_ReadMem(PEZOBJ_DS1307RTC ds, uint8 addr, uint8* result);
bool                DS1307RTC_WriteMem(PEZOBJ_DS1307RTC ds, uint8 addr, uint8 value);

void                DS1307RTC_SetClockRunning(PEZOBJ_DS1307RTC ds, bool running);
bool                DS1307RTC_IsClockRunning(PEZOBJ_DS1307RTC ds);

void                DS1307RTC_SetFixedOutputLevel(PEZOBJ_DS1307RTC ds, bool level);
bool                DS1307RTC_GetFixedOutputLevel(PEZOBJ_DS1307RTC ds);

void                DS1307RTC_SetSquareWaveEnabled(PEZOBJ_DS1307RTC ds, bool sqwe);
bool                DS1307RTC_IsSquareWaveEnabled(PEZOBJ_DS1307RTC ds);
void                DS1307RTC_SetSquareWaveRate(PEZOBJ_DS1307RTC ds, uint8 rate);
uint8               DS1307RTC_GetSquareWaveRate(PEZOBJ_DS1307RTC ds);



#endif
//[] END OF FILE