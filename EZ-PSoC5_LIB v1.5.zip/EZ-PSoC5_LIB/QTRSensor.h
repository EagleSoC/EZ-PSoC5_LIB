/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef QTRSENSORS_H
#define QTRSENSORS_H

#include "TypeDefine.h"
#include "ezCOMM.h"

#define QTR_MAX_SENSORS 16

typedef enum {
    QTR_EMITTERS_ON_AND_OFF,
    QTR_EMITTERS_ON,
    QTR_EMITTERS_OFF
} QTR_READMODE;

typedef enum {
    QTR_WHITE_LINE = 0,
    QTR_BLACK_LINE,
} QTR_LINE_TYPE;


typedef struct QTR_CONFIG{
    uint            TimeOut;
    QTR_READMODE    ReadMode;
    QTR_LINE_TYPE   LineType; 
    
    
} QTR_CONFIG;
    
    
typedef struct EZOBJ_QTR{
    void*       PrivateData;   
    QTR_CONFIG  Config;
    uint        sensorValues[QTR_MAX_SENSORS];
    
    
    
} EZOBJ_QTR;

typedef EZOBJ_QTR * PEZOBJ_QTR;



PEZOBJ_QTR      QTR_Create();

void            QTR_ConnectLedOnPin(PEZOBJ_QTR qrt, PEZOBJ_IO led);
void            QTR_ConnectIrArrayPin(PEZOBJ_QTR qrt, PEZOBJ_IO ir);
void            QTR_ConnectIrArrayPin2(PEZOBJ_QTR qrt, PEZOBJ_IO ir);

void            QTR_SetNumberSensors(PEZOBJ_QTR qrt, uint8_t numSensors);

bool            QTR_Init(PEZOBJ_QTR qtr);
void            QTR_Start(PEZOBJ_QTR qtr);

int             QTR_ReadLine(PEZOBJ_QTR qtr);








#endif

/* [] END OF FILE */
