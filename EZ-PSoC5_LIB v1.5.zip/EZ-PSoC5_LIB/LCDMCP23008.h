/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#if !defined(LCDMCP23008_H)
#define LCDMCP23008_H

//
#include "ezCOMM.h"
#include "ezI2C.h"
#include <cytypes.h>
#include "ezPSoC5.h"
#include <stdio.h> // for size_t


typedef enum{
    LCDMCP23008_LCD_5x10DOTS   = 0x04,
    LCDMCP23008_LCD_5x8DOTS    = 0x00
} LCDMCP23008_CONF_DOTSIZE;

    
    
    
typedef struct LCDMCP23008_Config{
    uint8_t                     Addr;
    uint8_t                     LcdLines;
    uint8_t                     LcdCols;
    LCDMCP23008_CONF_DOTSIZE    DotSize;
    
    
} LCDMCP23008_Config;
typedef LCDMCP23008_Config * PLCDMCP23008_Config;
    

typedef struct EZOBJ_LCDMCP23008 {
    void*           PrivateData;

    LCDMCP23008_Config Config;

} EZOBJ_LCDMCP23008;

typedef EZOBJ_LCDMCP23008 * PEZOBJ_LCDMCP23008;

PEZOBJ_LCDMCP23008  LCDMCP23008_Create();
void                LCDMCP23008_Release(PEZOBJ_LCDMCP23008 lcd);

void                LCDMCP23008_ConnectI2C(PEZOBJ_LCDMCP23008 lcd, PEZOBJ_I2C i2c);
//void                LCDMCP23008_ConnectSPI(PEZOBJ_LCDMCP23008 lcd, PEZOBJ_SPI isp);

bool                LCDMCP23008_Init (PEZOBJ_LCDMCP23008 lcd);            // Performs initialization required for component’s normal work
void                LCDMCP23008_Start(PEZOBJ_LCDMCP23008 lcd);            // Starts the module and loads custom character set to LCD if it was defined.

void                LCDMCP23008_SetBacklightOn(PEZOBJ_LCDMCP23008 lcd);
void                LCDMCP23008_SetBacklightOff(PEZOBJ_LCDMCP23008 lcd);

void                LCDMCP23008_DisplayOn(PEZOBJ_LCDMCP23008 lcd);        // Turns on the LCD module’s display
void                LCDMCP23008_DisplayOff(PEZOBJ_LCDMCP23008 lcd);       // Turns off the LCD module’s display

void                LCDMCP23008_ClearDisplay(PEZOBJ_LCDMCP23008 lcd);     // Clears the data from the LCD module’s screen
void                LCDMCP23008_Position(PEZOBJ_LCDMCP23008 lcd, uint8 row, uint8 col);   // Sets the cursor’s position to match the row and column supplied

void                LCDMCP23008_PrintString(PEZOBJ_LCDMCP23008 lcd, char8 string[]);
void                LCDMCP23008_PutChar(PEZOBJ_LCDMCP23008 lcd, uint8_t character);   // Sends a single character to the LCD module data register at the current position.
/* ASCII Conversion Routines */
void                LCDMCP23008_PrintInt8(PEZOBJ_LCDMCP23008 lcd, uint8 value);
void                LCDMCP23008_PrintInt16(PEZOBJ_LCDMCP23008 lcd, uint16 value) ;
void                LCDMCP23008_PrintInt32(PEZOBJ_LCDMCP23008 lcd, uint32 value) ;
void                LCDMCP23008_PrintU32Number(PEZOBJ_LCDMCP23008 lcd, uint32 value) ;


#define             LCDMCP23008_PrintNumber(lcd, value)    LCDMCP23008_PrintU32Number(lcd, (uint16) (value))
#define             LCDMCP23008_PrintDecUint16(lcd, x)     LCDMCP23008_PrintNumber(lcd, x)  
#define             LCDMCP23008_PrintHexUint8(lcd, x)      LCDMCP23008_PrintInt8(lcd, x)
#define             LCDMCP23008_PrintHexUint16(lcd, x)     LCDMCP23008_PrintInt16(lcd, x)        


#endif

//[] END OF FILE

