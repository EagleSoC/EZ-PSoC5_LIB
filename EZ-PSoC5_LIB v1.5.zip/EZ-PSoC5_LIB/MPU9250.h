/* ========================================
 *
 * Copyright AirSupplyLab.com, 2013
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF AirSupplyLab.com.
 *
 * Airs Lin
 * ========================================
*/

//------------------------------------------------------------
// *.h ///////////////////////////////////////////////////////
//------------------------------------------------------------

#ifndef MPU9250____H
#define MPU9250____H

#include "ezCOMM.h"
#include <cytypes.h>
#include "ezPSoC5.h"

//------------------------------------------------------------
// Defines ///////////////////////////////////////////////////
//------------------------------------------------------------

typedef enum{
    MPU9250_AD0_TO_GND                  = 0,
    MPU9250_AD0_TO_VCC                  = 1,
    MPU9250_AD0_AUTO                    = 2
} MPU9150_CONF_AD0_STATUS;
    
    
// Gyroscope Full-Scale Range
typedef enum {
    MPU9250_GYRO_FULLSCALE_250DPS       = 0x00,
    MPU9250_GYRO_FULLSCALE_500DPS       = 0x08,
    MPU9250_GYRO_FULLSCALE_1000DPS      = 0x10,
    MPU9250_GYRO_FULLSCALE_2000DPS      = 0x18
} MPU9250_CONF_GYRO_FULLSCALE;

// Accelerometer Full-Scale Range
typedef enum {
    MPU9250_ACC_FULLSCALE_2G            = 0x00,
    MPU9250_ACC_FULLSCALE_4G            = 0x08,
    MPU9250_ACC_FULLSCALE_8G            = 0x10,
    MPU9250_ACC_FULLSCALE_16G           = 0x18
} MPU9250_CONF_ACC_FULLSCALE;             



//------------------------------------------------------------
// Public Data Structure /////////////////////////////////////
//------------------------------------------------------------

typedef struct MPU9250_CONFIG{
    union{
    MPU9150_CONF_AD0_STATUS             AD0;
    uint8_t                             SPIAddress;
    };
    
    MPU9250_CONF_GYRO_FULLSCALE         GyroFullScale;
    MPU9250_CONF_ACC_FULLSCALE          AccFullScale;
    
} MPU9250_CONFIG;


typedef struct EZOBJ_MPU9250 {
    void*           PrivateData;
    
    VECTOR3Df       a;      // accelerometer reading
    VECTOR3Df       g;      // gyroscope reading
    VECTOR3Df       m;      // magnetometer reading
    
    float           tempC;  // Temperature    
    MPU9250_CONFIG  Config;

} EZOBJ_MPU9250;

typedef EZOBJ_MPU9250 * PEZOBJ_MPU9250;


//------------------------------------------------------------
// Public Functions //////////////////////////////////////////
//------------------------------------------------------------
PEZOBJ_MPU9250      MPU9250_Create();
void                MPU9250_Release(PEZOBJ_MPU9250 mpu);

void                MPU9250_ConnectI2C(PEZOBJ_MPU9250 mpu, PEZOBJ_I2C i2c);
void                MPU9250_ConnectSPI(PEZOBJ_MPU9250 mpu, PEZOBJ_SPI spi);
void                MPU9250_ConnectISR(PEZOBJ_MPU9250 mpu, PEZOBJ_ISR isr);

bool                MPU9250_Init (PEZOBJ_MPU9250 mpu);
void                MPU9250_Start(PEZOBJ_MPU9250 mpu);

bool                MPU9250_CalibrateAccGyro(PEZOBJ_MPU9250 mpu);


bool                MPU9250_ReadAcc(PEZOBJ_MPU9250 mpu);           // Output Unit: mg
bool                MPU9250_ReadGyro(PEZOBJ_MPU9250 mpu);          // Output Uint: dps/sec
bool                MPU9250_ReadGyroInDeg(PEZOBJ_MPU9250 mpu);     // Output Uint: Deg/sec
bool                MPU9250_ReadGyroInRad(PEZOBJ_MPU9250 mpu);     // Output Uint: Rad/sec
bool                MPU9250_ReadMag(PEZOBJ_MPU9250 mpu);           // Output Unit: Gauss

bool                MPU9250_ReadTemp(PEZOBJ_MPU9250 mpu);

// Interface
void                MPU9250_GetAccIntf (PEZOBJ_MPU9250 mpu, PEZOBJ_INTERFACE intf);
void                MPU9250_GetMagIntf (PEZOBJ_MPU9250 mpu, PEZOBJ_INTERFACE intf);
void                MPU9250_GetGyroIntf(PEZOBJ_MPU9250 mpu, PEZOBJ_INTERFACE intf);

#endif
/* [] END OF FILE */
 
