/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/


#ifndef EZRGBMATRIXPANEL__H
#define EZRGBMATRIXPANEL__H
    
#include "TypeDefine.h"
#include "ezFONTS.h"
#include "ezCOMM.h"
    
//------------------------------------------------------------
// Public Data Structure /////////////////////////////////////
//------------------------------------------------------------
    
typedef struct RGBMATRIXPANEL_CONFIG{
    uint8_t     ResolutionWidth;
    uint8_t     ResolutionHeight;
    bool        DoubleBuffer;
    bool        Wrap;
    
    
} RGBMATRIXPANEL_CONFIG;    


typedef struct EZOBJ_RGBMATRIXPANEL {
        
    void                    *PrivateData;
    RGBMATRIXPANEL_CONFIG   Config;    
    
    
} EZOBJ_RGBMATRIXPANEL; 
    
typedef EZOBJ_RGBMATRIXPANEL * PEZOBJ_RGBMATRIXPANEL;


//------------------------------------------------------------
// Public Functions //////////////////////////////////////////
//------------------------------------------------------------

PEZOBJ_RGBMATRIXPANEL   RGBMATRIXPANEL_Create();
void                    RGBMATRIXPANEL_Release(PEZOBJ_RGBMATRIXPANEL led);


void                    RGBMATRIXPANEL_ConnectISR(PEZOBJ_RGBMATRIXPANEL led, PEZOBJ_ISR isr);


bool                    RGBMATRIXPANEL_Init(PEZOBJ_RGBMATRIXPANEL led);
bool                    RGBMATRIXPANEL_Start(PEZOBJ_RGBMATRIXPANEL led);

void                    RGBMATRIXPANEL_SetFontSize(PEZOBJ_RGBMATRIXPANEL led, uint8 fontSize);
void                    RGBMATRIXPANEL_Position(PEZOBJ_RGBMATRIXPANEL led, uint8 row, uint8 col);
void                    RGBMATRIXPANEL_ClearDisplay(PEZOBJ_RGBMATRIXPANEL led);


void                    RGBMATRIXPANEL_SetTextColor(PEZOBJ_RGBMATRIXPANEL led, uint16_t c);
void                    RGBMATRIXPANEL_SetTextColorBg(PEZOBJ_RGBMATRIXPANEL led, uint16_t c, uint16_t bg);

void                    RGBMATRIXPANEL_PrintChar(PEZOBJ_RGBMATRIXPANEL led, char ch);
void                    RGBMATRIXPANEL_PrintString(PEZOBJ_RGBMATRIXPANEL led, const char text[]);
void                    RGBMATRIXPANEL_PrintStringLn(PEZOBJ_RGBMATRIXPANEL led, const char text[]);
void                    RGBMATRIXPANEL_PrintBuffer(PEZOBJ_RGBMATRIXPANEL led, uint8 buf[], uint16 len);


void                    RGBMATRIXPANEL_FillScreen(PEZOBJ_RGBMATRIXPANEL led, uint16_t c);

//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);
//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);
//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);
//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);
//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);
//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);
//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);
//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);
//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);
//void                    RGBMATRIXPANEL_ (PEZOBJ_RGBMATRIXPANEL led);


void                    RGBMATRIXPANEL_SwapBuffers(PEZOBJ_RGBMATRIXPANEL led, bool copy);

void                    RGBMATRIXPANEL_ISR_UpdateDisplay(PEZOBJ_RGBMATRIXPANEL led);    
    
    
uint16_t                RGBMATRIXPANEL_ColorHSV(long hue, uint8_t sat, uint8_t val, bool gflag);
    
#endif    
/* [] END OF FILE */
