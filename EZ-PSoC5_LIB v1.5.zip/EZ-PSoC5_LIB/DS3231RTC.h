/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/*
 * Chip Number : DS3231
 * Description : DS3231 I2C Real-Time Clock
 * Manufacture : Dallas Semiconductor
 * Web Site    : 
 * Interfaces  : Fast (400KHz) I2C Interface
 * Operator Vol: 3.3V ~ 5.5V
*/

#ifndef __DS3231RTC_H
#define __DS3231RTC_H

#include "ezCOMM.h"
#include "DS3231RTC.h"

//------------------------------------------------------------
// Defines ///////////////////////////////////////////////////
//------------------------------------------------------------
    
#if !defined(EZDATETIME_STRUCT)
    #define EZDATETIME_STRUCT
    
    #pragma pack(push)  // push current alignment to stack
    #pragma pack (1)    // Set alignment to 1 byte boundary
    typedef struct EZDATETIME {
        uint8   second;
        uint8   minute;
        uint8   hour24;
        uint8   dayOfWeek;
        uint8   day;
        uint8   month;
        uint16  year;
    } EZDATETIME;
    #pragma pack(pop)   // Restore original alignment from stack
    typedef EZDATETIME * PEZDATETIME;
    
    typedef enum EZDAYOFWEEK{
        SUNDAT = 0,
        MONDAY,
        TUESDAY,
        WEDNESDAY,
        THURSDAY,
        FRIDAY,
        SATURDAY
    } EZDAYOFWEEK;
    
#endif                  // !defined(EZDATETIME_STRUCT)

#define DS3231RTC_ALARM1_PER_SECOND                         0b01111
#define DS3231RTC_ALARM1_MATCH_SECONDS                      0b01110 
#define DS3231RTC_ALARM1_MATCH_MINUTES_SECONDS              0b01100
#define DS3231RTC_ALARM1_MATCH_HOURS_MINUTES_SECONDS        0b01000
#define DS3231RTC_ALARM1_MATCH_DATE_HOURS_MINUTES_SECONDS   0b00000
#define DS3231RTC_ALARM1_MATCH_DAY_HOURS_MINUTES_SECONDS    0b10000

#define DS3231RTC_ALARM2_PER_MINUTE                         0b00111
#define DS3231RTC_ALARM2_MATCH_MINUTES                      0b00110
#define DS3231RTC_ALARM2_MATCH_HOURS_MINUTES                0b00100
#define DS3231RTC_ALARM2_MATCH_DATE_HOURS_MINUTES           0b00000
#define DS3231RTC_ALARM2_MATCH_DAY_HOURS_MINUTES            0b10000

typedef enum DS3231RTC_ALARM_SOURCES{
    DS3231RTC_ALARM1_FLAG = 1,
    DS3231RTC_ALARM2_FLAG = 2
}DS3231RTC_ALARM_SOURCES;

typedef enum DS3231RTC_SQW_FREQ{
    DS3231RTC_SQW_RATE_1HZ,
    DS3231RTC_SQW_RATE_1024HZ,
    DS3231RTC_SQW_RATE_4096HZ,
    DS3231RTC_SQW_RATE_8192HZ
}DS3231RTC_SQW_FREQ;

typedef struct EZOBJ_DS3231RTC
{
    void*           PrivateData;

} EZOBJ_DS3231RTC;

typedef EZOBJ_DS3231RTC * PEZOBJ_DS3231RTC;



PEZOBJ_DS3231RTC    DS3231RTC_Create();
void                DS3231RTC_Release(PEZOBJ_DS3231RTC rtc);

void                DS3231RTC_ConnectI2C(PEZOBJ_DS3231RTC rtc, PEZOBJ_I2C i2c);

bool                DS3231RTC_Init (PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_Start(PEZOBJ_DS3231RTC rtc);

bool                DS3231RTC_Now(PEZOBJ_DS3231RTC rtc, PEZDATETIME datetime);

bool                DS3231RTC_GetOSCStatus(PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_EnableOSC   (PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_DisableOSC  (PEZOBJ_DS3231RTC rtc);

bool                DS3231RTC_IsDateTimeValid(PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_SetDateTime(PEZOBJ_DS3231RTC rtc, PEZDATETIME datetime);
void                DS3231RTC_SetDate    (PEZOBJ_DS3231RTC rtc, uint16 year, uint8 month, uint8 day, uint8 dayOfWeek);
void                DS3231RTC_SetTime    (PEZOBJ_DS3231RTC rtc, uint8 hour24, uint8 minute, uint8 second);

void                DS3231RTC_SetAlerm1(PEZOBJ_DS3231RTC rtc, uint8_t alarm, PEZDATETIME datetime);
void                DS3231RTC_SetAlerm2(PEZOBJ_DS3231RTC rtc, uint8_t alarm, PEZDATETIME datetime);
void                DS3231RTC_EnableAlarm1(PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_EnableAlarm2(PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_DisableAlarm1(PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_DisableAlarm2(PEZOBJ_DS3231RTC rtc);
DS3231RTC_ALARM_SOURCES  DS3231RTC_GetAlarmFlag(PEZOBJ_DS3231RTC rtc);

void                DS3231RTC_Enable32KHzOutput(PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_Disable32KHzOutput(PEZOBJ_DS3231RTC rtc);

void                DS3231RTC_SetSQWFreq(PEZOBJ_DS3231RTC rtc, uint8_t sqwFreq);
DS3231RTC_SQW_FREQ  DS3231RTC_GetSQWFreq(PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_EnableSQWOutput(PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_DisableSQWOutput(PEZOBJ_DS3231RTC rtc);

void                DS3231RTC_EnableBatteryBackedSQWOutput(PEZOBJ_DS3231RTC rtc);
void                DS3231RTC_DisableBatteryBackedSQWOutput(PEZOBJ_DS3231RTC rtc);

void                DS3231RTC_TriggleTemperatureConversion(PEZOBJ_DS3231RTC rtc);
bool                DS3231RTC_IsConvertDone(PEZOBJ_DS3231RTC rtc);
double              DS3231RTC_ReadTemperature(PEZOBJ_DS3231RTC rtc);

void                DS3231RTC_SetAginOffset(PEZOBJ_DS3231RTC rtc, int8_t offset);
int8_t              DS3231RTC_GetAginOffset(PEZOBJ_DS3231RTC rtc);


#endif

/* [] END OF FILE */
