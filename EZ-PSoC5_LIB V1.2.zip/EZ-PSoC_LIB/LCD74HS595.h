/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#if !defined(LCD74HS595_H)
#define LCD74HS595_H

//
#include "ezCOMM.h"
#include "ezI2C.h"
#include <cytypes.h>
#include "TypeDefine.h"
#include <stdio.h> // for size_t


typedef enum{
    LCD74HS595_LCD_5x10DOTS   = 0x04,
    LCD74HS595_LCD_5x8DOTS    = 0x00
} LCD74HS595_CONF_DOTSIZE;

    
    
    
typedef struct LCD74HS595_Config{
    uint8_t                     Addr;
    uint8_t                     LcdLines;
    uint8_t                     LcdCols;
    LCD74HS595_CONF_DOTSIZE     DotSize;
    
    
} LCD74HS595_Config;
typedef LCD74HS595_Config * PLCD74HS595_Config;
    

typedef struct EZOBJ_LCD74HS595 {
    void*           PrivateData;

    LCD74HS595_Config Config;

} EZOBJ_LCD74HS595;

typedef EZOBJ_LCD74HS595 * PEZOBJ_LCD74HS595;

PEZOBJ_LCD74HS595   LCD74HS595_Create();
void                LCD74HS595_Release(PEZOBJ_LCD74HS595 lcd);

void                LCD74HS595_ConnectSPI(PEZOBJ_LCD74HS595 lcd, PEZOBJ_SPI isp);

bool                LCD74HS595_Init (PEZOBJ_LCD74HS595 lcd);            // Performs initialization required for component’s normal work
void                LCD74HS595_Start(PEZOBJ_LCD74HS595 lcd);            // Starts the module and loads custom character set to LCD if it was defined.

void                LCD74HS595_SetBacklightOn(PEZOBJ_LCD74HS595 lcd);
void                LCD74HS595_SetBacklightOff(PEZOBJ_LCD74HS595 lcd);

void                LCD74HS595_DisplayOn(PEZOBJ_LCD74HS595 lcd);        // Turns on the LCD module’s display
void                LCD74HS595_DisplayOff(PEZOBJ_LCD74HS595 lcd);       // Turns off the LCD module’s display

void                LCD74HS595_ClearDisplay(PEZOBJ_LCD74HS595 lcd);     // Clears the data from the LCD module’s screen
void                LCD74HS595_Position(PEZOBJ_LCD74HS595 lcd, uint8 row, uint8 col);   // Sets the cursor’s position to match the row and column supplied

void                LCD74HS595_PrintString(PEZOBJ_LCD74HS595 lcd, char8 str[]);
void                LCD74HS595_PutChar(PEZOBJ_LCD74HS595 lcd, uint8_t value);   // Sends a single character to the LCD module data register at the current position.
/* ASCII Conversion Routines */
void                LCD74HS595_PrintInt8(PEZOBJ_LCD74HS595 lcd, uint8 value);
void                LCD74HS595_PrintInt16(PEZOBJ_LCD74HS595 lcd, uint16 value) ;
void                LCD74HS595_PrintInt32(PEZOBJ_LCD74HS595 lcd, uint32 value) ;
//void                LCD74HS595_PrintNumber(PEZOBJ_LCD74HS595 lcd, uint16 value) ; 
void                LCD74HS595_PrintU32Number(PEZOBJ_LCD74HS595 lcd, uint32 value) ;


#define             LCD74HS595_PrintNumber(lcd, value)    LCD74HS595_PrintU32Number(lcd, (uint16) (value))
#define             LCD74HS595_PrintDecUint16(lcd, x)     LCD74HS595_PrintNumber(lcd, x)  
#define             LCD74HS595_PrintHexUint8(lcd, x)      LCD74HS595_PrintInt8(lcd, x)
#define             LCD74HS595_PrintHexUint16(lcd, x)     LCD74HS595_PrintInt16(lcd, x)        


#endif

//[] END OF FILE

